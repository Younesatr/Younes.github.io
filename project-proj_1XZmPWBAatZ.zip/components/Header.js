function Header() {
  try {
    const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
    
    const navItems = [
      { name: 'Profile', href: 'profile.html' },
      { name: 'Experience', href: 'experience.html' },
      { name: 'Education', href: 'education.html' },
      { name: 'Skills', href: 'skills.html' },
      { name: 'Languages', href: 'languages.html' },
      { name: 'Certifications', href: 'certifications.html' }
    ];

    return (
      <header className="fixed top-0 left-0 right-0 z-50 bg-white shadow-sm" data-name="header" data-file="components/Header.js">
        <nav className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <a href="index.html" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[var(--secondary-color)]">
                <div className="icon-sun text-xl text-[var(--primary-color)]"></div>
              </div>
              <span className="text-xl font-bold text-[var(--dark-gray)]">Solar Portfolio</span>
            </a>
            
            <div className="hidden md:flex space-x-8">
              {navItems.map(item => (
                <a key={item.name} href={item.href} className="text-[var(--text-secondary)] hover:text-[var(--secondary-color)] transition-colors">
                  {item.name}
                </a>
              ))}
            </div>
            
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden">
              <div className={`icon-${mobileMenuOpen ? 'x' : 'menu'} text-2xl text-[var(--dark-gray)]`}></div>
            </button>
          </div>
          
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 space-y-3">
              {navItems.map(item => (
                <a key={item.name} href={item.href} className="block text-[var(--text-secondary)] hover:text-[var(--secondary-color)] transition-colors">
                  {item.name}
                </a>
              ))}
            </div>
          )}
        </nav>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}