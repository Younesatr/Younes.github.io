function Hero() {
  try {
    return (
      <section className="pt-32 pb-20 px-6 bg-gradient-to-br from-[var(--light-gray)] to-white" data-name="hero" data-file="components/Hero.js">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Solar Energy<br/>
                <span style={{color: 'var(--secondary-color)'}}>Technician</span>
              </h1>
              <p className="text-xl text-[var(--text-secondary)] mb-8 leading-relaxed">
                Specialized in PV installation, maintenance, R&D, and renewable energy system design. 
                Combining hands-on technical expertise with advanced 3D modeling and data analysis.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="profile.html" className="btn-primary">
                  View Profile
                </a>
                <a href="#contact" className="btn-secondary">
                  Contact Me
                </a>
              </div>
            </div>
            
            <div className="relative">
              <div className="aspect-square rounded-2xl bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] opacity-20"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-3/4 h-3/4 rounded-2xl bg-white shadow-2xl flex items-center justify-center">
                  <div className="icon-sun text-[120px]" style={{color: 'var(--primary-color)'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}