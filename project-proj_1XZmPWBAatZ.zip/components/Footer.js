function Footer() {
  try {
    return (
      <footer className="bg-[var(--dark-gray)] text-white py-12 px-6" data-name="footer" data-file="components/Footer.js">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[var(--secondary-color)]">
                  <div className="icon-sun text-xl text-[var(--primary-color)]"></div>
                </div>
                <span className="text-xl font-bold">Solar Portfolio</span>
              </div>
              <p className="text-gray-400">Professional Solar Energy Technician</p>
            </div>
            
            <div>
              <h3 className="font-bold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <a href="profile.html" className="block text-gray-400 hover:text-[var(--primary-color)] transition-colors">Profile</a>
                <a href="experience.html" className="block text-gray-400 hover:text-[var(--primary-color)] transition-colors">Experience</a>
                <a href="skills.html" className="block text-gray-400 hover:text-[var(--primary-color)] transition-colors">Skills</a>
              </div>
            </div>
            
            <div>
              <h3 className="font-bold mb-4">Connect</h3>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 rounded-lg flex items-center justify-center bg-gray-800 hover:bg-[var(--secondary-color)] transition-colors">
                  <div className="icon-linkedin text-xl text-white"></div>
                </a>
                <a href="#" className="w-10 h-10 rounded-lg flex items-center justify-center bg-gray-800 hover:bg-[var(--secondary-color)] transition-colors">
                  <div className="icon-github text-xl text-white"></div>
                </a>
                <a href="mailto:contact@example.com" className="w-10 h-10 rounded-lg flex items-center justify-center bg-gray-800 hover:bg-[var(--secondary-color)] transition-colors">
                  <div className="icon-mail text-xl text-white"></div>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>© 2025 Solar Energy Portfolio. All rights reserved.</p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}