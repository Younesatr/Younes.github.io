# Solar Energy Technician Portfolio

A professional portfolio website for a Solar Energy Technician showcasing expertise in PV installation, maintenance, R&D, and renewable energy systems.

## Project Structure

### Pages
- **index.html** - Landing page with hero section
- **profile.html** - Professional profile and bio
- **experience.html** - Work experience timeline
- **education.html** - Academic background
- **skills.html** - Technical and soft skills
- **languages.html** - Language proficiencies
- **certifications.html** - Professional certifications

### Components
- **Header.js** - Navigation header (responsive)
- **Hero.js** - Landing page hero section
- **Footer.js** - Site footer with links

## Design System

### Colors
- Primary: `#FFB703` (Yellow/Solar)
- Secondary: `#0057B8` (Solar Blue)
- Dark Gray: `#1a1a1a`
- Light Gray: `#f5f5f5`

### Typography
- Font Family: Inter, system fonts
- Clean, modern sans-serif style

### Style
- Modern professional theme
- Clean layouts with generous spacing
- Solar energy-inspired color palette
- Responsive design for all devices

## Features

- Fully responsive design
- Multi-page application structure
- Professional content placeholders
- Download CV button
- Contact information
- Social media links
- Smooth transitions
- Icon system using Lucide

## Target Audience

Recruiters and hiring managers in:
- Solar installation companies
- Renewable energy firms
- R&D laboratories
- Quality assurance teams
- System design organizations