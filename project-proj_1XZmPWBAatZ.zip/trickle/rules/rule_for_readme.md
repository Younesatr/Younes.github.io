When project structure, features, or pages are updated:
- Update the README.md in trickle/notes to reflect changes
- Keep the documentation current with actual implementation
- Document new pages, components, or features as they are added
- Update design system information if colors or styles change